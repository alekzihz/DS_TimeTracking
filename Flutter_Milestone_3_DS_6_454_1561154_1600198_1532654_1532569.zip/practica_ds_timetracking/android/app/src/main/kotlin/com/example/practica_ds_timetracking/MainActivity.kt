package com.example.practica_ds_timetracking

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
